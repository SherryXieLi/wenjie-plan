# 文杰学习 Wiki · 主页

> Huo Wenjie · 6 岁 · 2027 年 1 月新加坡公立小学 Primary 1 入学
> 6 年目标：**PSLE 4-6 分 → RI / HCI IP** （详见 [[profile/goals]]）

---

## 📊 12 维度能力速览

| 维度 | 现状 | 目标 | 状态 |
|---|---|---|---|
| 🇬🇧 听 | 4.0 | 4.5 | 🟢 |
| 🇬🇧 说 | 3.0 | 4.0 | 🟡 |
| 🇬🇧 读 | 3.0 | 4.0 | 🟡 |
| 🇬🇧 写 | 1.0 | 3.5 | 🔴 |
| 🇬🇧 Phonics | 2.5 | 4.5 | 🟡 |
| 🇬🇧 Sight Words | 22/52 | 40/52 | 🟡 |
| 🇨🇳 听 | 4.6 | 4.8 | 🟢 |
| 🇨🇳 说 | 4.2 | 4.5 | 🟢 |
| 🇨🇳 读 (Lv) | L6 | L8 | 🟡 |
| 🇨🇳 写 | 1.0 | 3.0 | 🔴 |
| 🇨🇳 识字量 | 390 | 600 | 🟡 |
| 🇨🇳 拼音 | 2.0 | 4.0 | 🟡 |

**详细**：
- 英文 → [[subjects/english/mastery]]
- 中文 → [[subjects/chinese/mastery]]
- 数学 → [[subjects/math/mastery]]
- 游泳 → [[subjects/swimming/mastery]]
- 钢琴 → [[subjects/piano/mastery]]

---

## 📅 本周 · W01 · 8/15-8/21

详见 [[plans/weekly/W01]]

**今天**：[[plans/daily/2026-08-15]] ✅（已完成 30%）
**明天**：[[plans/daily/2026-08-16]] ⭐ 轻量日 + 补 Timed Reading
**D3（8/17）**：[[plans/daily/2026-08-17]] 起点测评 Day 1

---

## 🎯 已识别的错误模式

详见 [[subjects/english/mistakes/pattern-001-long-short-vowels]] · [[subjects/english/mistakes/pattern-002-sight-words-spelling]] · [[subjects/chinese/mistakes/pattern-001-zh-ch-sh]]

---

## 🏊🎹 双 CCA 通道

- [[cca/swimming]] · [[subjects/swimming/mastery]] · 目标：RI / HCI DSA-Sports
- [[cca/piano]] · [[subjects/piano/mastery]] · 目标：RI MEP / HCI PA

---

## 📋 6 年路线

- 2027-2028 · [[school-readiness/p1-curriculum]] + [[school-readiness/p2-curriculum]] · 基础打牢
- 2029-2030 · [[school-readiness/p3-curriculum]] + [[school-readiness/p4-curriculum]] · 科学 + 加速
- 2031 · [[school-readiness/p5-curriculum]] · EM1 分流
- 2032 · [[school-readiness/p6-curriculum]] · PSLE 4-6 分 + DSA 申请
- 2033+ · [[school-readiness/dsa-overview]] · RI / HCI IP 入学

---

## 📚 资源

- 已有 → [[resources/bought]]
- 🚨 立即买 → [[resources/to-buy-now]]
- 📦 9 月前补齐 → [[resources/to-buy-by-september]]

---

## 📅 14 天内倒计时

- 8/29 前：[[subjects/math/entities/english-math-vocab]] 全过完 24 词
- 8/29 前：心算 6 级正确率 80%+
- 8/29 前：买 Singapore Math P1 Assessment Book 看格式
- 9/4 前：识字 390→500 + 拼音 zh/ch/sh 专项
- 9/4 前：决定 Jolly Phonics 买不买（D3 Phonics 测评后）
- 9/4 前：DSA 准备启动（[[dsa/dsa-application-timeline]]）

---

## 🔗 同步 UI

`~/Documents/Wenjie/` 里的 5 个 HTML UI 和这个 wiki 双向同步：

- [[README#详细 UI 链接]]（HTML 在 Documents/Wenjie/）
- 主页：master-overview.html
- 详细：progress-dashboard / daily-plan / school-readiness / cca-tracker
