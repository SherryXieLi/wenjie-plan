# 已有资源

## 中文
- ✅ [[../../subjects/chinese/entities/reading-levels|小羊上山]] L1-L6 60 册
- ✅ [[../../subjects/chinese/entities/character-recognition|小羊上山 L1-L5 字表]]

## 英文
- ✅ [[../../subjects/english/entities/letter-sounds|Oxford Phonics]] 1-5
- ✅ [[../../subjects/english/entities/reading-levels|牛津树 Oxford Reading Tree]] L1-L6

## 数学（珠心算）
- ✅ 正在读珠心算班
- 距考级 14 天（珠算 9 级 + 心算 6 级）

## 钢琴
- ✅ Trinity 1 级 Distinct（已考完）
- ✅ SPAF 1 级 Gold（2025-09，spaf.sg）
- 🔄 SPAF 3 级准备中（2026-09）
- 🔄 Trinity 3 级备考中
- 钢琴老师计划 P6 前考完 8 级

## 游泳
- ✅ 校外俱乐部（妈妈报班）
- ✅ Swim Safe 2 级（冲刺 3 级）
- ✅ 50m 自由/仰泳 ≈ 1:10
- ✅ Board Kicking 业余银牌
- 🔄 Swim Safe 3 级冲刺中

## 工具
- 待买：物理奖励贴纸 + 15 分钟沙漏（Daiso / Popular）

## 关联
- [[to-buy-now]] · [[to-buy-by-september]]
- [[../../subjects/english/mastery]] · [[../../subjects/chinese/mastery]] · [[../../subjects/math/mastery]]
- [[../../subjects/swimming/mastery]] · [[../../subjects/piano/mastery]]
